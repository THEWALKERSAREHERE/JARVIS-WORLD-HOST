package com.jarvis.worldhost

data class LibraryItem(
    val id: String,
    val displayName: String,
    val fileName: String,
    val extension: String,
    val category: String,
    val sizeBytes: Long,
    val importedAt: Long,
    val internalPath: String,
    val mirroredToShared: Boolean
)
