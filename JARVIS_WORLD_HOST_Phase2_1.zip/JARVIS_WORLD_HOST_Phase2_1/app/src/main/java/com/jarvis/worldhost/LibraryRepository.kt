package com.jarvis.worldhost

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class LibraryRepository(private val context: Context) {
    private val root = File(context.filesDir, "JARVIS_WORLD_HOST")
    private val worldsDir = File(root, "library/worlds")
    private val addonsDir = File(root, "library/addons")
    private val backupsDir = File(root, "backups")
    private val indexFile = File(root, "library-index.json")
    private val prefs = context.getSharedPreferences("jarvis_world_host", Context.MODE_PRIVATE)

    init {
        worldsDir.mkdirs()
        addonsDir.mkdirs()
        backupsDir.mkdirs()
        if (!indexFile.exists()) indexFile.writeText("[]")
    }

    fun listItems(): List<LibraryItem> {
        val array = try { JSONArray(indexFile.readText()) } catch (_: Exception) { JSONArray() }
        val result = mutableListOf<LibraryItem>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val path = o.optString("internalPath")
            if (path.isBlank() || !File(path).exists()) continue
            result += LibraryItem(
                id = o.optString("id"),
                displayName = o.optString("displayName"),
                fileName = o.optString("fileName"),
                extension = o.optString("extension"),
                category = o.optString("category"),
                sizeBytes = o.optLong("sizeBytes"),
                importedAt = o.optLong("importedAt"),
                internalPath = path,
                mirroredToShared = o.optBoolean("mirroredToShared")
            )
        }
        return result.sortedByDescending { it.importedAt }
    }

    fun sharedFolderName(): String {
        val raw = prefs.getString("shared_tree_uri", null) ?: return "Not connected"
        return try {
            val tree = DocumentFile.fromTreeUri(context, Uri.parse(raw))
            tree?.name ?: "Shared folder connected"
        } catch (_: Exception) { "Shared folder unavailable" }
    }

    fun saveSharedFolder(uri: Uri) {
        prefs.edit().putString("shared_tree_uri", uri.toString()).apply()
    }

    fun importFile(uri: Uri): LibraryItem {
        val originalName = queryDisplayName(uri) ?: "import_${System.currentTimeMillis()}"
        val extension = originalName.substringAfterLast('.', "").lowercase()
        val category = when (extension) {
            "mcworld" -> "world"
            "mcaddon", "mcpack" -> "addon"
            else -> throw IllegalArgumentException("Unsupported file type. Choose .mcworld, .mcaddon, or .mcpack.")
        }
        val destinationDir = if (category == "world") worldsDir else addonsDir
        val safeName = uniqueName(destinationDir, sanitizeFileName(originalName))
        val destination = File(destinationDir, safeName)
        val temp = File(destinationDir, "$safeName.part")

        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Android could not open the selected file." }
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            }
            if (!temp.renameTo(destination)) {
                temp.copyTo(destination, overwrite = true)
                temp.delete()
            }
        } catch (e: Exception) {
            temp.delete()
            throw e
        }

        var mirrored = false
        try {
            mirrored = mirrorToShared(destination, category)
        } catch (_: Exception) {
            mirrored = false
        }

        val item = LibraryItem(
            id = UUID.randomUUID().toString(),
            displayName = originalName.substringBeforeLast('.', originalName),
            fileName = safeName,
            extension = extension,
            category = category,
            sizeBytes = destination.length(),
            importedAt = System.currentTimeMillis(),
            internalPath = destination.absolutePath,
            mirroredToShared = mirrored
        )
        val items = listItems().toMutableList()
        items.add(item)
        saveIndex(items)
        return item
    }

    fun backup(item: LibraryItem): File {
        val source = File(item.internalPath)
        require(source.exists()) { "The library file no longer exists." }
        val stamp = System.currentTimeMillis()
        val backup = File(backupsDir, "${source.nameWithoutExtension}_$stamp.${item.extension}")
        source.copyTo(backup, overwrite = false)
        return backup
    }

    fun export(item: LibraryItem, destinationUri: Uri) {
        val source = File(item.internalPath)
        require(source.exists()) { "The library file no longer exists." }
        context.contentResolver.openOutputStream(destinationUri, "w").use { output ->
            requireNotNull(output) { "Android could not open the export destination." }
            FileInputStream(source).use { input -> input.copyTo(output) }
        }
    }

    private fun mirrorToShared(source: File, category: String): Boolean {
        val raw = prefs.getString("shared_tree_uri", null) ?: return false
        val tree = DocumentFile.fromTreeUri(context, Uri.parse(raw)) ?: return false
        val folderName = if (category == "world") "Worlds" else "Addons"
        val folder = tree.findFile(folderName) ?: tree.createDirectory(folderName) ?: return false
        val targetName = uniqueDocumentName(folder, source.name)
        val target = folder.createFile("application/octet-stream", targetName) ?: return false
        context.contentResolver.openOutputStream(target.uri, "w").use { output ->
            requireNotNull(output)
            FileInputStream(source).use { input -> input.copyTo(output) }
        }
        return true
    }

    private fun uniqueDocumentName(folder: DocumentFile, name: String): String {
        if (folder.findFile(name) == null) return name
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var n = 2
        while (true) {
            val candidate = if (ext.isBlank()) "${base}_$n" else "${base}_$n.$ext"
            if (folder.findFile(candidate) == null) return candidate
            n++
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index)
            }
        }
        return uri.lastPathSegment
    }

    private fun sanitizeFileName(value: String): String {
        val cleaned = value.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            .replace(Regex("\\s+"), "_")
            .trim('_', '.', ' ')
        return cleaned.ifBlank { "import_${System.currentTimeMillis()}" }
    }

    private fun uniqueName(directory: File, name: String): String {
        if (!File(directory, name).exists()) return name
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var n = 2
        while (true) {
            val candidate = if (ext.isBlank()) "${base}_$n" else "${base}_$n.$ext"
            if (!File(directory, candidate).exists()) return candidate
            n++
        }
    }

    private fun saveIndex(items: List<LibraryItem>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id)
                put("displayName", item.displayName)
                put("fileName", item.fileName)
                put("extension", item.extension)
                put("category", item.category)
                put("sizeBytes", item.sizeBytes)
                put("importedAt", item.importedAt)
                put("internalPath", item.internalPath)
                put("mirroredToShared", item.mirroredToShared)
            })
        }
        val temp = File(root, "library-index.json.part")
        temp.writeText(array.toString(2))
        if (!temp.renameTo(indexFile)) {
            temp.copyTo(indexFile, overwrite = true)
            temp.delete()
        }
    }
}
