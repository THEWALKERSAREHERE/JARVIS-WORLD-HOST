package com.jarvis.worldhost

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.ImportExport
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private val Cyan = Color(0xFF21C7E8)
private val Background = Color(0xFF090D12)
private val Panel = Color(0xFF121A23)
private val Muted = Color(0xFF9AA9B8)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private lateinit var repository: LibraryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = LibraryRepository(this)

        setContent {
            val scope = rememberCoroutineScope()
            var library by remember { mutableStateOf(repository.listItems()) }
            var message by remember { mutableStateOf("JARVIS WORLD HOST initialized. Import an add-on, then run the compatibility scan.") }
            var busy by remember { mutableStateOf(false) }
            var sharedFolder by remember { mutableStateOf(repository.sharedFolderName()) }
            var exportTarget by remember { mutableStateOf<LibraryItem?>(null) }
            var scanReports by remember { mutableStateOf<List<AddonCompatibilityChecker.Report>>(emptyList()) }
            var minecraftVersion by remember { mutableStateOf("") }
            var versionComparisonDone by remember { mutableStateOf(false) }

            fun refresh() {
                library = repository.listItems()
                sharedFolder = repository.sharedFolderName()
            }

            val importLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri: Uri? ->
                if (uri != null) {
                    busy = true
                    scope.launch {
                        try {
                            val item = withContext(Dispatchers.IO) { repository.importFile(uri) }
                            refresh()
                            message = "Imported ${item.fileName}" +
                                if (item.mirroredToShared) " and copied it to the shared folder." else "."
                        } catch (e: Exception) {
                            message = e.message ?: "Import failed."
                        } finally { busy = false }
                    }
                }
            }

            val folderLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocumentTree()
            ) { uri: Uri? ->
                if (uri != null) {
                    try {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                        repository.saveSharedFolder(uri)
                        refresh()
                        message = "Shared folder connected. New imports will be mirrored there."
                    } catch (e: Exception) {
                        message = "Could not retain access to that folder: ${e.message}"
                    }
                }
            }

            val exportLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.CreateDocument("application/octet-stream")
            ) { uri: Uri? ->
                val item = exportTarget
                if (uri != null && item != null) {
                    busy = true
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { repository.export(item, uri) }
                            message = "Exported ${item.fileName}."
                        } catch (e: Exception) {
                            message = e.message ?: "Export failed."
                        } finally {
                            busy = false
                            exportTarget = null
                        }
                    }
                } else {
                    exportTarget = null
                }
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan,
                    background = Background,
                    surface = Panel,
                    onPrimary = Color.Black,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                Scaffold(
                    containerColor = Background,
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("JARVIS", fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                                    Text("WORLD HOST · PHASE 2.1", fontSize = 10.sp, color = Muted, letterSpacing = 1.5.sp)
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = Background,
                                titleContentColor = Color.White
                            )
                        )
                    }
                ) { padding ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            StatusPanel(
                                worlds = library.count { it.category == "world" },
                                addons = library.count { it.category == "addon" },
                                sharedFolder = sharedFolder
                            )
                        }
                        item {
                            Text("WORLD LIBRARY", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionButton(
                                    label = "Import World",
                                    icon = { Icon(Icons.Default.Gamepad, null) },
                                    modifier = Modifier.weight(1f),
                                    enabled = !busy
                                ) { importLauncher.launch(arrayOf("*/*")) }
                                ActionButton(
                                    label = "Import Add-on",
                                    icon = { Icon(Icons.Default.Inventory2, null) },
                                    modifier = Modifier.weight(1f),
                                    enabled = !busy
                                ) { importLauncher.launch(arrayOf("*/*")) }
                            }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { folderLauncher.launch(null) },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !busy
                            ) {
                                Icon(Icons.Default.FolderOpen, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Connect shared folder")
                            }
                            Text(
                                "Import accepts .mcworld, .mcaddon and .mcpack. The app keeps an internal copy and mirrors new imports to the shared folder when connected.",
                                color = Muted, fontSize = 11.sp
                            )
                        }
                        item {
                            Text("ADD-ON COMPATIBILITY", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    busy = true
                                    scope.launch {
                                        try {
                                            val addonFiles = library.filter { it.category == "addon" }.map { File(it.internalPath) }
                                            scanReports = withContext(Dispatchers.IO) {
                                                AddonCompatibilityChecker().scanLibrary(addonFiles)
                                            }
                                            versionComparisonDone = false
                                            val errors = scanReports.sumOf { it.errorCount }
                                            val warnings = scanReports.sumOf { it.warningCount }
                                            message = "Scan complete: ${scanReports.size} add-on file(s), $errors error(s), $warnings warning(s)."
                                        } catch (e: Exception) {
                                            message = e.message ?: "Compatibility scan failed."
                                        } finally { busy = false }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !busy && library.any { it.category == "addon" }
                            ) {
                                Icon(Icons.Default.Inventory2, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (busy) "Scanning…" else "Scan Imported Add-ons")
                            }
                            Text(
                                "Checks manifests, pack types, UUIDs, dependencies and declared Minecraft minimum versions. It does not modify your files.",
                                color = Muted, fontSize = 11.sp
                            )
                            Spacer(Modifier.height(12.dp))
                            Text("HOST MINECRAFT VERSION", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = minecraftVersion,
                                onValueChange = { value ->
                                    minecraftVersion = value.filter { it.isDigit() || it == '.' }.take(16)
                                    versionComparisonDone = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("Installed version") },
                                placeholder = { Text("Example: 1.21.130") },
                                supportingText = { Text("Enter the version shown on the Minecraft title screen or settings.") },
                                isError = minecraftVersion.isNotBlank() && !AddonCompatibilityChecker().isValidMinecraftVersion(minecraftVersion)
                            )
                            OutlinedButton(
                                onClick = {
                                    try {
                                        scanReports = AddonCompatibilityChecker().compareWithMinecraftVersion(scanReports, minecraftVersion)
                                        versionComparisonDone = true
                                        val errors = scanReports.sumOf { it.errorCount }
                                        val warnings = scanReports.sumOf { it.warningCount }
                                        message = "Version comparison complete for Minecraft $minecraftVersion: $errors error(s), $warnings warning(s)."
                                    } catch (e: Exception) {
                                        message = e.message ?: "Version comparison failed."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = scanReports.isNotEmpty() && AddonCompatibilityChecker().isValidMinecraftVersion(minecraftVersion) && !busy
                            ) {
                                Text(if (versionComparisonDone) "Recompare Version" else "Compare Add-ons With This Version")
                            }
                        }
                        if (scanReports.isNotEmpty()) {
                            item {
                                Text("SCAN RESULTS", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            }
                            items(scanReports, key = { "scan_${it.fileName}" }) { report ->
                                CompatibilityReportCard(report)
                            }
                        }
                        item {
                            Text("IMPORTED FILES", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        }
                        if (library.isEmpty()) {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.Archive, null, tint = Cyan, modifier = Modifier.size(36.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text("No worlds or add-ons yet", fontWeight = FontWeight.Bold)
                                        Text("Import a .mcworld or add-on package to populate the library.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                        } else {
                            items(library, key = { it.id }) { item ->
                                LibraryCard(
                                    item = item,
                                    onExport = {
                                        exportTarget = item
                                        exportLauncher.launch(item.fileName)
                                    },
                                    onBackup = {
                                        scope.launch {
                                            try {
                                                val backup = withContext(Dispatchers.IO) { repository.backup(item) }
                                                message = "Backup created: ${backup.name}"
                                            } catch (e: Exception) {
                                                message = e.message ?: "Backup failed."
                                            }
                                        }
                                    }
                                )
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("PHASE 2.1 STATUS", color = Cyan, fontWeight = FontWeight.Bold)
                                    Text("World/add-on import · Internal library · Shared-folder mirror · Export · Backup · Manifest scan · UUID checks · Dependency checks · Host-version comparison", fontSize = 12.sp)
                                    Text("Still planned: world pack activation, safe world-copy preparation, Minecraft launch handoff and LAN hosting workflow.", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                        item {
                            Text(message, color = if (message.contains("failed", true) || message.contains("could not", true)) Color(0xFFFFB36B) else Muted, fontSize = 12.sp)
                        }
                        item { Spacer(Modifier.height(24.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompatibilityReportCard(report: AddonCompatibilityChecker.Report) {
    val statusColor = when {
        report.errorCount > 0 -> Color(0xFFFF7777)
        report.warningCount > 0 -> Color(0xFFFFC66D)
        else -> Cyan
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(report.fileName, fontWeight = FontWeight.Bold)
                    Text(report.status, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Text("${report.errorCount}E · ${report.warningCount}W", color = statusColor, fontSize = 10.sp)
            }
            report.packs.forEach { pack ->
                Text("${pack.name} · ${pack.type}", fontSize = 12.sp)
                Text("UUID: ${pack.uuid}", color = Muted, fontSize = 10.sp)
                Text("Pack version: ${pack.version.joinToString(".")}", color = Muted, fontSize = 10.sp)
                pack.minEngineVersion?.let {
                    Text("Minimum Minecraft: ${it.joinToString(".")}", color = Muted, fontSize = 10.sp)
                }
            }
            report.findings.forEach { finding ->
                val color = when (finding.severity) {
                    AddonCompatibilityChecker.Severity.ERROR -> Color(0xFFFF7777)
                    AddonCompatibilityChecker.Severity.WARNING -> Color(0xFFFFC66D)
                    AddonCompatibilityChecker.Severity.INFO -> Muted
                }
                Text("${finding.severity.name}: ${finding.message}", color = color, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun StatusPanel(worlds: Int, addons: Int, sharedFolder: String) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("COMMAND CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Text("My Worlds", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.Storage, tint = Cyan, modifier = Modifier.size(34.dp), contentDescription = null)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("WORLDS", worlds.toString(), Modifier.weight(1f))
                StatTile("ADD-ONS", addons.toString(), Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FolderOpen, tint = Cyan, modifier = Modifier.size(16.dp), contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("Shared storage: $sharedFolder", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF0B1118), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Cyan)
        }
    }
}

@Composable
private fun ActionButton(
    label: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(onClick = onClick, modifier = modifier.heightIn(min = 52.dp), enabled = enabled) {
        icon()
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
private fun LibraryCard(item: LibraryItem, onExport: () -> Unit, onBackup: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (item.category == "world") Icons.Default.Gamepad else Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = Cyan
                )
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.displayName, fontWeight = FontWeight.Bold)
                    Text("${item.extension.uppercase()} · ${formatBytes(item.sizeBytes)}", color = Muted, fontSize = 11.sp)
                }
                Surface(color = Color(0xFF12313A), shape = RoundedCornerShape(50)) {
                    Text(if (item.category == "world") "WORLD" else "ADD-ON", color = Cyan, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                }
            }
            Text(
                "Internal copy saved" + if (item.mirroredToShared) " · Shared copy saved" else " · Not mirrored",
                color = Muted, fontSize = 10.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onExport, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.ImportExport, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Export", fontSize = 12.sp)
                }
                OutlinedButton(onClick = onBackup, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Backup", fontSize = 12.sp)
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    return String.format("%.1f MB", kb / 1024.0)
}
