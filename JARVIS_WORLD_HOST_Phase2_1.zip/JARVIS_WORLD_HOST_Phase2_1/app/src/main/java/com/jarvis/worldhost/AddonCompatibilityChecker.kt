package com.jarvis.worldhost

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

/** Reads Bedrock pack manifests without extracting or modifying the source archive. */
class AddonCompatibilityChecker {
    companion object {
        private const val MAX_MANIFEST_BYTES = 1024 * 1024
        private const val MAX_NESTED_ARCHIVE_BYTES = 32 * 1024 * 1024
        private const val MAX_TOTAL_EXPANDED_BYTES = 96L * 1024L * 1024L
        private const val MAX_ENTRIES = 3000
        private const val MAX_NESTED_DEPTH = 3
    }

    data class Finding(val severity: Severity, val message: String)
    enum class Severity { ERROR, WARNING, INFO }

    data class Dependency(val uuid: String, val version: List<Int>)
    data class Pack(
        val name: String,
        val uuid: String,
        val version: List<Int>,
        val type: String,
        val minEngineVersion: List<Int>?,
        val dependencies: List<Dependency>,
        val sourceEntry: String
    )

    data class Report(
        val fileName: String,
        val packs: List<Pack>,
        val findings: List<Finding>
    ) {
        val errorCount get() = findings.count { it.severity == Severity.ERROR }
        val warningCount get() = findings.count { it.severity == Severity.WARNING }
        val status: String get() = when {
            errorCount > 0 -> "Issues found"
            warningCount > 0 -> "Review warnings"
            packs.isEmpty() -> "No pack manifests"
            else -> "No issues detected"
        }
    }

    fun scanLibrary(files: List<File>): List<Report> {
        val reports = files.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in setOf("mcpack", "mcaddon") }
            .map { scan(it) }
        val allPacks = reports.flatMap { it.packs }
        val uuidOwners = allPacks.groupBy { it.uuid.lowercase(Locale.ROOT) }
        return reports.map { report ->
            val extra = mutableListOf<Finding>()
            report.packs.forEach { pack ->
                val owners = uuidOwners[pack.uuid.lowercase(Locale.ROOT)].orEmpty()
                if (owners.size > 1) {
                    extra += Finding(Severity.ERROR, "Duplicate pack UUID ${pack.uuid} appears more than once in the imported add-on library.")
                }
            }
            report.packs.forEach { pack ->
                pack.dependencies.forEach { dep ->
                    val match = allPacks.firstOrNull { it.uuid.equals(dep.uuid, ignoreCase = true) }
                    if (match == null) {
                        extra += Finding(Severity.WARNING, "Missing dependency ${dep.uuid} (required version ${dep.version.joinToString(".")}).")
                    } else if (compareVersions(match.version, dep.version) != 0) {
                        extra += Finding(Severity.WARNING, "Dependency ${dep.uuid} requests ${dep.version.joinToString(".")}, but the library has ${match.version.joinToString(".")}.")
                    }
                }
            }
            report.copy(findings = (report.findings + extra).distinctBy { it.severity to it.message })
        }
    }

    /** Adds a host-version assessment to existing scan results. Version must be major.minor.patch. */
    fun compareWithMinecraftVersion(reports: List<Report>, installedVersionText: String): List<Report> {
        val installedVersion = parseVersionText(installedVersionText)
            ?: throw IllegalArgumentException("Enter the installed Minecraft version as three numbers, for example 1.21.130.")

        return reports.map { report ->
            val versionFindings = mutableListOf<Finding>()
            val retainedFindings = report.findings.filterNot { it.message.startsWith("Host version check:") }
            report.packs.forEach { pack ->
                val minimum = pack.minEngineVersion
                if (minimum == null) {
                    versionFindings += Finding(
                        Severity.WARNING,
                        "Host version check: ${pack.name} has no valid min_engine_version, so compatibility with Minecraft ${installedVersion.joinToString(".")} cannot be confirmed."
                    )
                } else if (compareVersions(installedVersion, minimum) < 0) {
                    versionFindings += Finding(
                        Severity.ERROR,
                        "Host version check: ${pack.name} requires Minecraft ${minimum.joinToString(".")} or newer; installed version is ${installedVersion.joinToString(".")}. This pack is below its declared minimum."
                    )
                } else {
                    versionFindings += Finding(
                        Severity.INFO,
                        "Host version check: ${pack.name} is declared for Minecraft ${minimum.joinToString(".")} or older; installed version ${installedVersion.joinToString(".")} meets that minimum. This does not guarantee full gameplay/API compatibility."
                    )
                }
            }
            report.copy(findings = (retainedFindings + versionFindings).distinctBy { it.severity to it.message })
        }
    }

    fun isValidMinecraftVersion(value: String): Boolean = parseVersionText(value) != null

    private fun parseVersionText(value: String): List<Int>? {
        val match = Regex("^\\s*(\\d+)\\.(\\d+)\\.(\\d+)(?:\\.\\d+)?\\s*$").matchEntire(value)
            ?: return null
        return match.groupValues.drop(1).take(3).mapNotNull { it.toIntOrNull() }
            .takeIf { it.size == 3 && it.all { part -> part >= 0 } }
    }

    fun scan(file: File): Report {
        val findings = mutableListOf<Finding>()
        val packs = mutableListOf<Pack>()
        if (!file.exists() || !file.isFile) {
            return Report(file.name, emptyList(), listOf(Finding(Severity.ERROR, "File is missing or is not a regular file.")))
        }
        if (file.length() <= 0L) {
            return Report(file.name, emptyList(), listOf(Finding(Severity.ERROR, "File is empty.")))
        }
        if (file.length() > MAX_TOTAL_EXPANDED_BYTES) {
            return Report(file.name, emptyList(), listOf(Finding(Severity.ERROR, "Archive is larger than the checker safety limit (96 MB).")))
        }
        try {
            file.inputStream().use { scanArchive(it, file.name, 0, packs, findings, Budget()) }
        } catch (e: Exception) {
            findings += Finding(Severity.ERROR, "Could not read archive: ${e.message ?: "invalid ZIP data"}")
        }
        if (packs.isEmpty() && findings.none { it.severity == Severity.ERROR }) {
            findings += Finding(Severity.ERROR, "No valid manifest.json was found in this package.")
        }
        if (packs.isNotEmpty()) findings += Finding(Severity.INFO, "Found ${packs.size} pack manifest(s). Original file was not changed.")
        return Report(file.name, packs, findings)
    }

    private class Budget(var expandedBytes: Long = 0L, var entries: Int = 0)

    private fun scanArchive(
        input: InputStream,
        sourceName: String,
        depth: Int,
        packs: MutableList<Pack>,
        findings: MutableList<Finding>,
        budget: Budget
    ) {
        if (depth > MAX_NESTED_DEPTH) {
            findings += Finding(Severity.WARNING, "$sourceName: nested archive depth limit reached.")
            return
        }
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                budget.entries++
                if (budget.entries > MAX_ENTRIES) {
                    findings += Finding(Severity.ERROR, "Archive contains too many entries; scan stopped for safety.")
                    return
                }
                if (!entry.isDirectory) {
                    val entryName = entry.name
                    when {
                        entryName.substringAfterLast('/').equals("manifest.json", ignoreCase = true) -> {
                            val bytes = readBounded(zip, MAX_MANIFEST_BYTES)
                            budget.expandedBytes += bytes.size
                            if (budget.expandedBytes > MAX_TOTAL_EXPANDED_BYTES) {
                                findings += Finding(Severity.ERROR, "Expanded archive data exceeded the 96 MB safety limit.")
                                return
                            }
                            parseManifest(bytes, "$sourceName!/$entryName", packs, findings)
                        }
                        entryName.endsWith(".mcpack", ignoreCase = true) -> {
                            val bytes = readBounded(zip, MAX_NESTED_ARCHIVE_BYTES)
                            budget.expandedBytes += bytes.size
                            if (budget.expandedBytes > MAX_TOTAL_EXPANDED_BYTES) {
                                findings += Finding(Severity.ERROR, "Expanded archive data exceeded the 96 MB safety limit.")
                                return
                            }
                            scanArchive(ByteArrayInputStream(bytes), "$sourceName!/$entryName", depth + 1, packs, findings, budget)
                        }
                        else -> {
                            // Drain every entry through a bounded stream so ZIP bombs in ignored assets are also limited.
                            val remaining = (MAX_TOTAL_EXPANDED_BYTES - budget.expandedBytes).coerceAtLeast(0L)
                            val ignoredBytes = drainBounded(zip, remaining)
                            budget.expandedBytes += ignoredBytes
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun readBounded(input: InputStream, limit: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (output.size() + count > limit) throw IllegalArgumentException("An archive entry exceeded the safety limit.")
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun drainBounded(input: InputStream, limit: Long): Long {
        val buffer = ByteArray(8192)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > limit) throw IllegalArgumentException("Expanded archive data exceeded the 96 MB safety limit.")
        }
        return total
    }

    private fun parseManifest(
        bytes: ByteArray,
        sourceEntry: String,
        packs: MutableList<Pack>,
        findings: MutableList<Finding>
    ) {
        val json = try { JSONObject(bytes.toString(Charsets.UTF_8)) } catch (e: Exception) {
            findings += Finding(Severity.ERROR, "$sourceEntry: manifest.json is not valid JSON.")
            return
        }
        val header = json.optJSONObject("header")
        if (header == null) {
            findings += Finding(Severity.ERROR, "$sourceEntry: manifest is missing the header object.")
            return
        }
        val uuid = header.optString("uuid", "").trim()
        if (!isUuid(uuid)) {
            findings += Finding(Severity.ERROR, "$sourceEntry: header UUID is missing or invalid.")
            return
        }
        val version = parseVersion(header.opt("version"))
        if (version == null) {
            findings += Finding(Severity.ERROR, "$sourceEntry: header version must contain three non-negative integers.")
            return
        }
        val modules = json.optJSONArray("modules") ?: JSONArray()
        if (modules.length() == 0) findings += Finding(Severity.WARNING, "$sourceEntry: manifest has no modules.")
        val types = mutableSetOf<String>()
        for (i in 0 until modules.length()) {
            val module = modules.optJSONObject(i) ?: continue
            when (module.optString("type").lowercase(Locale.ROOT)) {
                "resources" -> types += "Resource Pack"
                "data", "script" -> types += "Behavior Pack"
                else -> findings += Finding(Severity.WARNING, "$sourceEntry: module $i has an unrecognized type '${module.optString("type")}'.")
            }
            val moduleUuid = module.optString("uuid", "")
            if (moduleUuid.isNotBlank() && !isUuid(moduleUuid)) {
                findings += Finding(Severity.ERROR, "$sourceEntry: module $i has an invalid UUID.")
            }
            if (parseVersion(module.opt("version")) == null) {
                findings += Finding(Severity.ERROR, "$sourceEntry: module $i has a missing or invalid version.")
            }
        }
        val type = when {
            types.size == 1 -> types.first()
            types.size > 1 -> "Mixed Pack"
            else -> "Unknown Pack"
        }
        if (types.size > 1) findings += Finding(Severity.WARNING, "$sourceEntry: this manifest mixes resource and behavior module types.")
        val engineVersion = if (header.has("min_engine_version")) parseVersion(header.opt("min_engine_version")) else null
        if (header.has("min_engine_version") && engineVersion == null) {
            findings += Finding(Severity.WARNING, "$sourceEntry: min_engine_version is malformed.")
        }
        val dependencies = mutableListOf<Dependency>()
        val deps = json.optJSONArray("dependencies") ?: JSONArray()
        for (i in 0 until deps.length()) {
            val dep = deps.optJSONObject(i) ?: continue
            val depUuid = dep.optString("uuid", "").trim()
            val depVersion = parseVersion(dep.opt("version"))
            if (!isUuid(depUuid) || depVersion == null) {
                findings += Finding(Severity.ERROR, "$sourceEntry: dependency $i has an invalid UUID or version.")
            } else {
                dependencies += Dependency(depUuid, depVersion)
            }
        }
        val name = header.optJSONObject("name")?.optString("value")
            ?: header.optString("name", "Unnamed pack")
        packs += Pack(name, uuid, version, type, engineVersion, dependencies, sourceEntry)
        if (engineVersion != null) findings += Finding(Severity.INFO, "$name requires Minecraft ${engineVersion.joinToString(".")} or newer; compare this with the version installed on the host.")
    }

    private fun isUuid(value: String): Boolean = try {
        UUID.fromString(value).toString().equals(value, ignoreCase = true)
    } catch (_: Exception) { false }

    private fun parseVersion(value: Any?): List<Int>? {
        val array = value as? JSONArray ?: return null
        if (array.length() != 3) return null
        val parts = (0 until 3).map { index ->
            val number = array.opt(index)
            when (number) {
                is Int -> number
                is Long -> if (number in 0..Int.MAX_VALUE.toLong()) number.toInt() else return null
                else -> return null
            }
        }
        return parts.takeIf { it.all { part -> part >= 0 } }
    }

    private fun compareVersions(left: List<Int>, right: List<Int>): Int {
        for (i in 0 until 3) {
            val result = left[i].compareTo(right[i])
            if (result != 0) return result
        }
        return 0
    }
}
