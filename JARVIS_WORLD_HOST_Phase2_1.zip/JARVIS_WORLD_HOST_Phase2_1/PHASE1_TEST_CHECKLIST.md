# JARVIS WORLD HOST — Test checklist

## Build and install

- [ ] Build with JDK 17+ / Gradle 8.9 / Android SDK 35.
- [ ] Install the debug APK on Samsung Galaxy A17 5G.
- [ ] Launch app and confirm dashboard renders without crashing.

## Library regression tests

- [ ] Import one `.mcworld` file.
- [ ] Import one `.mcpack` file.
- [ ] Import one `.mcaddon` file.
- [ ] Confirm internal copies exist and filenames are safely de-duplicated.
- [ ] Connect a shared folder and confirm future imports are mirrored.
- [ ] Export an imported file and compare its bytes with the original.
- [ ] Create a backup and confirm the library original remains unchanged.

## Phase 2 manifest scanner tests

Prepare test archives with known manifests:

- [ ] Valid behavior pack manifest (`modules[].type = data`).
- [ ] Valid resource pack manifest (`modules[].type = resources`).
- [ ] `.mcaddon` containing nested `.mcpack` archives.
- [ ] Missing `manifest.json`.
- [ ] Invalid JSON manifest.
- [ ] Missing or malformed header UUID.
- [ ] Invalid header/module version arrays.
- [ ] Duplicate pack header UUIDs across two imported files.
- [ ] Dependency UUID absent from the imported library.
- [ ] Dependency UUID present with matching version.
- [ ] Dependency UUID present with a different version.
- [ ] Malformed `min_engine_version`.
- [ ] Oversized or deeply nested archive is stopped by safety limits.
- [ ] Confirm source `.mcpack` / `.mcaddon` bytes remain unchanged after scanning.

## Known limitations to verify in later phases

- [ ] Compare `min_engine_version` with the Minecraft version installed on the phone.
- [ ] Prepare a working copy of a world and attach pack UUID/version references safely.
- [ ] Hand the prepared world to Minecraft Android.
- [ ] Host a Bedrock LAN world from Minecraft and join it from PS5.

## Phase 2.1 version comparison tests

- [ ] Scan imported add-ons and confirm manifest results appear.
- [ ] Enter the exact Minecraft Android version in `major.minor.patch` format.
- [ ] Confirm malformed or incomplete version strings disable the comparison button.
- [ ] Compare against a pack with a higher `min_engine_version`; expect an ERROR.
- [ ] Compare against a pack whose minimum is met; expect an INFO finding.
- [ ] Compare again with a different version; confirm old host-version findings are replaced.
- [ ] Confirm a pack without a valid `min_engine_version` gets a WARNING.
- [ ] Confirm original `.mcpack` / `.mcaddon` files remain unchanged.
