# Phase 2.1 — Installed Minecraft Version Comparison

## User workflow

1. Import one or more `.mcpack` or `.mcaddon` files.
2. Tap **Scan Imported Add-ons**.
3. Read the manifest, UUID, module, and dependency findings.
4. Find the Minecraft version displayed by the Minecraft Android app.
5. Enter it in **Host Minecraft Version** using `major.minor.patch` format, such as `1.21.130` (example format only; use the version actually installed).
6. Tap **Compare Add-ons With This Version**.
7. Review the findings on each pack.

## Comparison rules

- Installed version lower than a pack's `min_engine_version`: ERROR; the installed host is below the pack's declared minimum.
- Installed version equal to or higher than the declared minimum: INFO; the minimum requirement is met.
- Missing or malformed `min_engine_version`: WARNING; the checker cannot confirm the requirement.
- Re-comparing after changing the version replaces prior host-version findings instead of leaving stale results.

## Important limitations

- The version is entered manually. The app does not inspect Minecraft's private files or claim to auto-detect the installed version.
- `min_engine_version` is a declared minimum, not a complete compatibility guarantee.
- This comparison does not validate Script API versions, experimental toggles, server/client behavior, resource content, or runtime errors.
- The checker reads imported archive copies and does not modify the original package.
