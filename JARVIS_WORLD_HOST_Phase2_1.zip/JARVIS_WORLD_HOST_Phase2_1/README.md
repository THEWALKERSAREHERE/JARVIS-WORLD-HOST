# JARVIS WORLD HOST — Phase 2

A native Android foundation for managing Minecraft Bedrock worlds and add-ons, with an initial add-on manifest compatibility scanner.

## Project configuration

- Package: `com.jarvis.worldhost`
- App version: `0.3.0-phase2.1`
- Minimum Android: API 26 (Android 8.0)
- Compile / target SDK: 35
- Kotlin: 1.9.25
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- UI: Jetpack Compose + Material 3

## Phase 1 features

- Import `.mcworld`, `.mcaddon`, and `.mcpack` files using Android's document picker.
- Store internal copies in the app's private files directory.
- Optionally mirror new imports to a user-selected shared folder.
- Export imported files and create internal backups.
- Preserve imported originals; imports are copied, not edited.

## Phase 2 features

- Scan imported `.mcpack` and `.mcaddon` ZIP archives.
- Read Bedrock `manifest.json` files, including `.mcpack` files nested inside `.mcaddon` archives.
- Identify behavior packs, resource packs, mixed packs, and unknown module types.
- Validate header UUIDs, pack versions, module UUIDs and module versions.
- Detect duplicate pack UUIDs across the imported add-on library.
- Check dependency UUIDs and requested versions against packs found in the library.
- Report declared `min_engine_version` values.
- Let the user enter the exact Minecraft Bedrock version installed on the Android host.
- Compare that version against every pack's declared `min_engine_version`.
- Flag packs whose declared minimum is newer than the installed Minecraft version; report packs whose declared minimum is met.
- Re-run version comparisons without retaining stale results from an earlier version entry.
- Apply archive entry, nested-depth, and expanded-size limits while scanning. The checker does not extract or modify the source archives.

## Important Phase 2 limitations

- The scanner is a structural manifest check, not a guarantee that an add-on will run correctly.
- It does not inspect JavaScript behavior-pack code, texture/model content, or all gameplay/API compatibility requirements.
- The installed Minecraft version is entered manually; the app does not silently read Minecraft's private app data or infer the version.
- Passing the minimum-version check is not a guarantee of full compatibility. Script API requirements, experimental toggles, content errors, and runtime behavior need separate checks or in-game testing.
- Missing dependencies are warnings because the required pack may be installed outside this app's library.
- World pack activation, safe world-copy preparation, Minecraft launch handoff, and LAN hosting workflow are not implemented yet.

## Build requirements

- JDK 17 or newer (JDK 21 is suitable).
- Android SDK Platform 35 and Build Tools 35.0.0.
- Gradle 8.9.

This project includes Gradle wrapper properties but not the wrapper JAR or launcher scripts. Install Gradle 8.9, then from the project root run:

```bash
gradle :app:assembleDebug
```

Expected APK:

`app/build/outputs/apk/debug/app-debug.apk`

## Storage behavior

Internal library path:

`/data/data/com.jarvis.worldhost/files/JARVIS_WORLD_HOST/`

The shared-folder mirror uses a folder selected by the user through Android's Storage Access Framework. The app does not access Minecraft's private data directory or alter existing Minecraft worlds.

## Platform reality

The Android app can prepare files and hand them to Minecraft, but Minecraft itself must load and host the Bedrock world. The PS5 joins the Android-hosted world over the same local network when Minecraft versions and multiplayer/account requirements permit it.
