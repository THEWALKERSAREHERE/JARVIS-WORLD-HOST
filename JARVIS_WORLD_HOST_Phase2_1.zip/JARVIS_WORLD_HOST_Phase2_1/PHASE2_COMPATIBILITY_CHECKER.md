# Phase 2 — Add-on Compatibility Checker

## Scan flow

1. User imports `.mcpack` or `.mcaddon` through the existing library flow.
2. The app stores an untouched internal copy.
3. User taps **Scan Imported Add-ons**.
4. The scanner opens the archive as a ZIP stream and reads manifest entries.
5. For `.mcaddon`, nested `.mcpack` entries are scanned recursively within configured limits.
6. Parsed pack metadata is compared across the imported add-on library.
7. The dashboard displays pack type, UUID, pack version, minimum engine version, and findings.

## Finding severity

- **ERROR** — malformed manifest data, invalid required UUID/version, invalid module metadata, or duplicate pack UUID.
- **WARNING** — missing dependency, dependency version mismatch, missing modules, mixed/unknown module types, or malformed minimum engine version.
- **INFO** — scan metadata and declared minimum Minecraft version.

## Safety limits

- Manifest JSON entry: 1 MiB maximum.
- Nested `.mcpack` entry: 32 MiB maximum.
- Total counted expanded data: 96 MiB maximum.
- Total archive entries across nested archives: 3,000 maximum.
- Nested archive depth: 3 maximum.
- Source archives are streamed/read only; no extraction or rewriting is performed.

## What this scan cannot prove

A clean report does not guarantee runtime compatibility. Script API usage, JavaScript errors, resource references, content schema versions, experimental toggles, game bugs, and Minecraft version-specific behavior still require separate checks and in-game testing. A missing dependency may exist outside the app's imported library.
